module.exports = {
  UserController: require('./user'),
  ConferenceController: require('./conference'),
  GuestController: require('./guest'),
  LocateController: require('./locate'),
  BudgetController: require('./budget'),
  TaskController: require('./task')
}
